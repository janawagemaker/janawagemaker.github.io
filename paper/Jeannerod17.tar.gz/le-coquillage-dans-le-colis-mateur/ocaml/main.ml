
open Format
open Why3extract
open Base__Syntax
open Base__Semantics
open Interpreter__CorrectTermInterpreter
open Interpreter__Interpreter

let rec tseqs = function
  | [] -> assert false
  | [t] -> t
  | t :: tl -> TSeq (t, tseqs tl)


type test = {
    t_term : term ;
    t_stdin : string ;
    t_args : string list ;
    t_stdout : string ;
    t_behaviour : behaviour ;
  }

let add_parenthesis (need_par: bool) (s: string) =
  (if need_par then "(" else "") ^ s ^ (if need_par then ")" else "")

let rec term_to_string (need_par: bool) = function
  | TTrue -> "true"
  | TFalse -> "false"
  | TFatal -> "fatal"
  | TReturn t         -> add_parenthesis need_par ("return " ^ term_to_string true t)
  | TExit t           -> add_parenthesis need_par ("exit " ^ term_to_string true t)
  | TAsString (x, s)  -> add_parenthesis need_par (x ^ " :=s " ^ sexpr_to_string true s)
  | TAsList (x, l)    -> add_parenthesis need_par (x ^ " :=l " ^ lexpr_to_string false l)
  | TSeq (t1, t2)     -> add_parenthesis need_par ((term_to_string false t1) ^ "; " ^ term_to_string false t2)
  | TIf (t1, t2, t3)  -> add_parenthesis need_par ("if " ^ (term_to_string true t1) ^ " then " ^ (term_to_string true t2) ^ " else " ^ (term_to_string true t3))
  | TDoWhile (t1, t2) -> add_parenthesis need_par ("do " ^ (term_to_string true t1) ^ " while " ^ (term_to_string true t2))
  | TProcess t        -> add_parenthesis need_par ("process " ^ (term_to_string true t))
  | TCall ll          -> add_parenthesis (need_par && (List.length ll > 0)) ("call " ^ lexpr_to_string true ll)
  | TPipe (t1, t2)    -> add_parenthesis need_par ("pipe " ^ (term_to_string true t1) ^ " into " ^ (term_to_string true t2))
  | _ -> " [[[NOT IMPLEMENTED]]] "

and sexpr_to_string (need_par: bool) (sl: sfrag list) =
  let s = List.fold_left (fun s l -> s ^ sfrag_to_string l) "" sl in
  (if need_par then "\"" else "") ^ s ^ (if need_par then "\"" else "")

and sfrag_to_string = function
  | SLiteral s -> s
  | SVar s -> "$" ^ s
  | SProcess t -> "$(" ^ (term_to_string false t) ^ ")"
  | _ -> " [[[NOT IMPLEMENTED]]] "

and lexpr_to_string (need_par: bool) (ll: lfrag list) =
  let s = List.fold_left (fun s l -> s ^ ", " ^ lfrag_to_string l) "" ll in
  "[" ^ (String.sub s 2 ((String.length s) - 2)) ^ "]"

and lfrag_to_string = function
  | LSingleton sl -> sexpr_to_string true sl
  | LSplit sl -> sexpr_to_string false sl
  | LVar s -> "$" ^ s
  | _ -> " [[[NOT IMPLEMENTED]]] "

let print_term t =
  print_string (term_to_string false t)

let behaviour_to_string = function
  | BNormal true -> "True"
  | BNormal false -> "False"
  | BFatal -> "Fatal"
  | BReturn true -> "Return True"
  | BReturn false -> "Return False"
  | BExit true -> "Exit True"
  | BExit false -> "Exit False"

let print_behaviour b =
  print_string (behaviour_to_string b)


let run_test (t: test) =
  (* Print term *)
  print_string "\x1B[36;1mTERM:\x1B[0m "; print_term t.t_term; print_newline ();

  (* Run interpreter *)
  let stdout = ref "" in
  let (b, g') =
    try
      let (b, g') = interp_term t.t_term {empty_context with c_args = t.t_args ; c_input = t.t_stdin} stdout in
      (BNormal b, g')
    with
    | EFatal g' -> (BFatal, g')
    | EReturn (b, g') -> (BReturn b, g')
    | EExit (b, g') -> (BExit b, g')
  in

  (* Print stdout *)
  print_string "\x1B[36;1mSTDOUT:\x1B[0m "; print_string !stdout; print_newline ();
  if !stdout <> t.t_stdout then
    ( print_string "\x1B[31;1mEXPECTED:\x1B[0m "; print_string t.t_stdout; print_newline () );

  (* Print behaviour *)
  print_string "\x1B[36;1mBEHAVIOUR:\x1B[0m "; print_behaviour b; print_newline ();
  if b <> t.t_behaviour then
    ( print_string "\x1B[31;1mEXPECTED:\x1B[0m "; print_behaviour t.t_behaviour; print_newline () )



let run_tests (tl: test list) =
  let rec run_tests_aux (n: int) = function
    | [] -> Format.printf "\x1B[34;1m===== THE END =====@."
    | t :: tl' ->
       Format.printf "\x1B[34;1m===== TEST #%d =====\x1B[0m@." n;
       run_test t;
       Format.printf "@.";
       run_tests_aux (n+1) tl'
  in
  run_tests_aux 1 tl



let _ =
  run_tests [
      (* Test #1 *)

      { t_term = TTrue ;
        t_stdin = "" ;
        t_args = [] ;
        t_stdout = "" ;
        t_behaviour = BNormal true } ;

      (* Test #2 *)

      { t_term = TIf (TFatal, TFalse, TTrue) ;
        t_stdin = "" ;
        t_args = [] ;
        t_stdout = "" ;
        t_behaviour = BNormal true } ;

      (* Test #3

         x1=false
         x2=true

         do
           echo "$x1" "$x2"
           if "$x1"; then x2=false; else x1=true; fi
         while "$x2"

         echo "$x1" "$x2" *)

      { t_term =
          tseqs [
              TAsString ("x1", [SLiteral "false"]) ;
              TAsString ("x2", [SLiteral "true"])  ;
              TDoWhile (
                  TSeq (
                      TCall [LSingleton [SLiteral "echo"]; LSingleton [SVar "x1"]; LSingleton [SVar "x2"]],
                      TIf (
                          TCall [LSingleton [SVar "x1"]],
                          TAsString ("x2", [SLiteral "false"]),
                          TAsString ("x1", [SLiteral "true"])
                        )
                    ),
                  TCall [LSingleton [SVar "x2"]]
                ) ;
              TCall [LSingleton [SLiteral "echo"]; LSingleton [SVar "x1"]; LSingleton [SVar "x2"]]
            ] ;
        t_stdin = "" ;
        t_args = [] ;
        t_stdout = "false true\ntrue true\ntrue false\n" ;
        t_behaviour = BNormal true } ;

      (* Test #4
         x="foo $(false) bar" || echo $x *)

      { t_term =
          TIf (
              TAsString ("x", [SLiteral "foo "; SProcess TFatal; SLiteral " bar"]),
              TTrue,
              TCall [LSingleton [SLiteral "echo"]; LSplit [SVar "x"]]
            ) ;
        t_stdin = "";
        t_args = [] ;
        t_stdout = "foo bar\n" ;
        t_behaviour = BNormal true } ;

      (* Test #5
         x="echo foo"; $x && "$x" *)

      { t_term =
          TSeq (
              TAsString ("x", [SLiteral "echo foo"]),
              TIf (
                  TCall [LSplit [SVar "x"]],
                  TCall [LSingleton [SVar "x"]],
                  TFalse
                )
            ) ;
        t_stdin = "";
        t_args = [];
        t_stdout = "foo\n";
        t_behaviour = BFatal } ;

      (* Test #6
         x=; ! true; $x *)

      { t_term =
          tseqs [
              TAsString ("x", []) ;
              TFalse ;
              TCall [LSplit [SVar "x"]]
            ] ;
        t_stdin = "";
        t_args = [];
        t_stdout = "";
        t_behaviour = BNormal true } ;

      (* Test #7

         echo "$(return 0)foo"
         exit 2 | echo bar
         ( exit 3 ) || echo baz *)

      { t_term =
          tseqs [
              TCall [LSplit [SLiteral "echo"]; LSingleton [SProcess (TReturn TTrue); SLiteral "foo"]];
              TPipe (
                  TExit TFalse,
                  TCall [LSplit [SLiteral "echo bar"]]
                );
              TIf (
                  TProcess (TExit TFatal),
                  TTrue,
                  TCall [LSplit [SLiteral "echo baz"]]
                )
            ];
        t_stdin = "";
        t_args = [];
        t_stdout = "foo\nbar\nbaz\n";
        t_behaviour = BNormal true }
              

    ]
