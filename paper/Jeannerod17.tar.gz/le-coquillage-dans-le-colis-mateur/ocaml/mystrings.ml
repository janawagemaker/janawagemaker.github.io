
let why3_split_string c s =
  if s = "" then
    []
  else
    (
      let rec aux acc i =
        try
          let j = String.index_from s i c in
          if j > i then
            aux (String.sub s i (j-i) :: acc) (j + 1)
          else aux acc (j+1)
        with
        | Not_found -> (String.sub s i (String.length s - i))::acc
        | Invalid_argument _ -> acc in
      List.rev (aux [] 0)
    )
