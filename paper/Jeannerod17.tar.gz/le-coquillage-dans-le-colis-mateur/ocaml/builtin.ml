open Base__Syntax
open Base__Semantics

let eval f g =
  match f with
  | "true" ->
     ("", BReturn true, g)
  | "false" ->
     ("", BReturn false, g)
  | "fatal" ->
     ("", BFatal, g)
  | "echo" ->
     let res = List.fold_left (fun res arg -> res ^ " " ^ arg) "" g.c_args in
     ((String.sub res 1 ((String.length res) - 1)) ^ "\n", BReturn true, g)
  | _ ->
     ("", BFatal, g)
